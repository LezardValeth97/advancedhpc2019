/usr/local/cuda/bin/nvcc -o exercise1 -Iinclude *.cu *.cpp
