/usr/local/cuda/bin/nvcc -o Exercise2 -Iinclude -std=c++11 \
    main.cpp Exercise.cu

