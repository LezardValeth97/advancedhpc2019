#pragma once
#include "Matrix.cuh"

Matrix productCPU(Matrix &a, Matrix &b) {

}